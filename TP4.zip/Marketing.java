public class Marketing extends Division {

    public Marketing(int baseSalary) {
        super(baseSalary);
    }
    
    @Override
    public void addEmployee(Employee employee) {
        super.addEmployee(employee);
        // TODO: Lengkapi
    }

    @Override
    public String getDivisionName() {
        return "Marketing";
    }
}
