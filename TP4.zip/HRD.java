public class HRD extends Division {

    public HRD(int baseSalary) {
        super(baseSalary);
    }
    
    @Override
    public void addEmployee(Employee employee) {
        super.addEmployee(employee);
        // TODO: Lengkapi
    }

    @Override
    public String getDivisionName() {
        return "HRD";
    }
}
