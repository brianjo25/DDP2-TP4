public class Engineering extends Division{

    public Engineering(int baseSalary) {
        super(baseSalary);
    }
    
    @Override
    public void addEmployee(Employee employee) {
        super.addEmployee(employee);
        // TODO: Lengkapi
    }

    @Override
    public String getDivisionName() {
        return "Engineering";
    }
}
