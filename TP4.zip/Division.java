import java.util.List;

public class Division {
    // TODO: Tambahkan modifier untuk atribut
    int baseSalary;
    List<Employee> employeeList;

    // TODO: Lengkapi constructor
    public Division(int baseSalary) {
        
    }

    // TODO: Lengkapi logika untuk menambahkan karyawan
    public void addEmployee(Employee employee) {

    }

    // Tambahkan getter & setter lainnya sesuai kebutuhan

    public int getBaseSalary() {
        return this.baseSalary;
    }

    public String getDivisionName() {
        return "";
    }
}
