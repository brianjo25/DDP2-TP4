import java.util.List;

public class Project {
    // TODO: Tambahkan modifier untuk atribut
    String name;
    Manager projectLeader;
    List<Employee> memberList;

    // TODO: Lengkapi constructor
    public Project(String name) {
        
    }

    // TODO: Lengkapi logika menambahkan anggota proyek
    public void addMember(Employee employee) {

    }


    // TODO: Lengkapi logika menghapus anggota proyek
    public void removeMember(Employee employee) {

    }

    public String getName() {
        return this.name;
    }
}
